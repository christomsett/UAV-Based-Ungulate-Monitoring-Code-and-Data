

##### set-up ####

# packages 
library(ggplot2)
library(dplyr)
library(tidyr)
library(MCMCvis)
library(boot) # inv.logit()
library(nimble)



setwd("C:/Users/ellie.scopes/OneDrive - Forest Research/Documents/NCF Squirrel Project/R/Ungulates clean code")



########### Ground to air comparison ####

## Figure 5 - comparing species detections ####

# read in data of each ungulate detection
ungulates <- read.csv("data/Ungulate detections.csv") %>% 
  filter(is.na(Notes))
# remove results from a survey with a second ground crew (removing second crew detections only)

# make nicer labels for graphing
ungulates <- ungulates %>% mutate(UAV.species=case_when(UAV.species%in%c("Animal","?") ~ "Unknown\nanimal",
                                                        UAV.species=="Ungulate" ~ "Unknown\nungulate",
                                                        UAV.species=="Deer" ~ "Unknown\ndeer",
                                                        T ~ UAV.species),
                                  Ground.species=case_when(Ground.species%in%c("Animal","?") ~ "Unknown\nanimal",
                                                           Ground.species=="Ungulate" ~ "Unknown\nungulate",
                                                           Ground.species=="Deer" ~ "Unknown\ndeer",
                                                           T ~ Ground.species))
# create categories from the binary detections
ungulates <- ungulates %>% mutate(category=case_when(UAV==1 & Ground==1 ~ "Both",
                                                     UAV==1 & Ground==0 ~ "UAV only",
                                                     UAV==0 & Ground==1 ~ "Ground only"))


# overall
ungulates %>% group_by(category) %>% 
  summarise(n=n())
# Both = 31
# Ground only = 23
# UAV only = 75


# detections by one survey type, summed over species
single <- ungulates %>% filter(UAV==0 | Ground==0) %>% 
  unite("species", UAV.species, Ground.species, na.rm=T) %>% 
  group_by(category, species) %>% 
  summarise(total=n())

# detections by both survey types, summed over species
both <- ungulates %>% filter(UAV==1 & Ground==1) %>% 
  group_by(category, UAV.species) %>% 
  summarise(UAV.total=n()) %>% 
  select(category, species=UAV.species, UAV.total) %>% 
  merge(ungulates %>% filter(UAV==1 & Ground==1) %>% 
          group_by(category, Ground.species) %>% 
          summarise(Ground.total=n())%>% 
          select(category, species=Ground.species, Ground.total),
        by=c("category", "species"), all=T) %>% 
  mutate(across(UAV.total:Ground.total, ~replace_na(.x, 0)))



# combine again for plotting
combo <- both %>% pivot_longer(UAV.total:Ground.total, values_to = "total") %>% 
  mutate(category=case_when(name=="UAV.total" ~ "Both - UAV",
                            name=="Ground.total" ~ "Both - Ground")) %>% 
  select(-name) %>% 
  rbind(single) %>% 
  # better labels for graphing
  mutate(species=case_when(species=="Wild Boar" ~ "Boar",
                           species=="Deer" ~ "Unknown\ndeer",
                           T ~ species))

# order species names for graph
combo$species <- factor(combo$species, levels=c("Boar","Fallow","Roe","Muntjac","Unknown\ndeer","Unknown\nungulate", "Unknown\nanimal"))



# UAV - digure 5A
ggplot(filter(combo, grepl("UAV", category)), aes(x=species, y=total, fill=category)) +
  geom_col(colour="black") +
  theme_classic() +
  scale_y_continuous(breaks=seq(0,40,5), limits=c(0,40)) +
  ylab("Number of sightings") +
  scale_fill_manual(values=c("orchid", "skyblue")) +
  theme(legend.title = element_blank(),
        axis.title = element_text(size=40), axis.text=element_text(size=35),
        legend.text = element_text(size=35))

ggsave("results/Ground_air_comparison_UAV.jpeg", width=25, height=10)


# Ground - Figure 5B
ggplot(filter(combo, grepl("Ground", category)), aes(x=species, y=total, fill=category)) +
  geom_col(colour="black") +
  theme_classic() +
  scale_y_continuous(breaks=seq(0,40,5), limits=c(0,40)) + # limits same on both panels
  ylab("Number of sightings") +
  scale_fill_manual(values=c("purple", "forestgreen")) +
  theme(legend.title = element_blank(),
        axis.title = element_text(size=40), axis.text=element_text(size=35),
        legend.text = element_text(size=35))

ggsave("results/Ground_air_comparison_ground.jpeg", width=25, height=10)


## Table 2 -  confusion matrix #####

# create matrix from ungulates info
confusion <- ungulates %>% filter(UAV==1 & Ground==1) %>% 
  # replace graphing labels with readbale ones
  mutate(across(Ground.species:UAV.species, ~stringr::str_replace(.x,"\n", " "))) %>% 
  # suammrise by species from each detection
  group_by(Ground.species, UAV.species) %>% 
  summarise(tot=n()) %>% 
  # pivot so ground species become columns
  pivot_wider(names_from = Ground.species, values_from = tot) %>% 
  select(UAV.species,Boar, Fallow, Roe, Muntjac,  `Unknown deer`, `Unknown ungulate`)


# add roe deer to UAV species
confusion <- confusion %>% 
  rbind(c("Roe", rep(NA,6)))
# levels so can arrange
confusion$UAV.species <- factor(confusion$UAV.species, levels=c("Boar","Fallow","Roe","Muntjac","Unknown deer","Unknown ungulate", "Unknown animal", "Ground total"))
confusion <- confusion %>% arrange(UAV.species)
# make numeric
confusion <-confusion %>% mutate(across(Boar:`Unknown ungulate`, ~ as.numeric(.x)))


# add UAV total
confusion <- confusion %>% ungroup() %>% 
  mutate(`UAV total`=rowSums(across(Boar:`Unknown ungulate`), na.rm=T))

# add Ground total 
confusion <- confusion %>% rbind(c("Ground total", colSums(confusion[,2:8], na.rm = T)))

# get rid of NAs
confusion <-confusion %>% mutate(across(Boar:`Unknown ungulate`, ~ replace_na(.x, " ")))

confusion

write.csv(confusion, "results/confusion_matrix.csv", row.names=F)



##### Bayesian modelling ####

## get data ####

# read in data of each ungulate detection
ungulates <- read.csv("data/Ungulate detections.csv") %>% 
  filter(is.na(Notes))
# remove results from a survey with a second ground crew (removing second crew detections only)

# create the three categories
ungulates <- ungulates %>% mutate(category=case_when(UAV==1 & Ground==1 ~ 3,
                                                     UAV==1 & Ground==0 ~ 2,
                                                     UAV==0 & Ground==1 ~ 1))

# reduce columns
ungulates <- ungulates %>% select(ID, category, Trial, Transect)

# convert transects to numbers for model
# in order then "W035" "W036" "W037" "W038" "W069""W073" 
ungulates <- ungulates %>% mutate(Transect=case_when(Transect== "W035"~ 1,
                                                     Transect== "W036"~ 2,
                                                     Transect== "W037"~ 3,
                                                     Transect== "W038"~ 4,
                                                     Transect== "W069"~ 5,
                                                     Transect== "W073"~ 6))

# read in habitat data 
habitats <- read.csv("data/Bayesian_habitats.csv")

# merge 
ungulates <- ungulates %>% merge(habitats, by="ID")

# select only columns needed
ungulates <- ungulates %>% select(category, Trial, Transect, Habitat)

# double check sample sizes
ungulates %>% group_by(Habitat) %>% 
  summarise(n=n())
# only one young forest - can't include 
# remove
ungulates <- ungulates %>% filter(Habitat != "Young_Forest")
#128 samples


# habitat numbers
ungulates <- ungulates %>% mutate(Habitat=case_when(Habitat== "Deciduous_Forest"~ 1,
                                                    Habitat== "Evergreen_Forest"~ 2,
                                                    Habitat== "Open_Land"~ 3,
                                                    T ~ NA))

## model ####

detection.habitat.int <- nimbleCode({
  
  # Priors - vague
  
  # intercepts 
  mean.ground ~ dunif(0,1)
  mean.UAV ~ dunif(0,1)
  
  alpha.ground <- logit(mean.ground)
  alpha.UAV <- logit(mean.UAV)
  
  # trial effects - random effect
  for (t in 1:trials){
    alpha.trial[t] ~ dnorm(mu.trial, sig.trial)
  }
  # hyperparameters
  mu.trial  ~ dnorm(0,0.1)
  sig.trial ~ dunif(0,1)
  
  
  
  # transects effects - random
  # an 'intercept' like model where first level is 0 and others are in comparison to this mean
  alpha.transect[1]  <- 0
  for (t in 2:transects){
    
    alpha.transect[t]  ~ dnorm(mu.transect , sig.transect)
  }
  
  mu.transect ~ dnorm(0,0.1) 
  sig.transect ~ dunif(0,1)
  
  # habitat effects - fixed 
  alpha.UAV.habitat[1] <- 0
  alpha.ground.habitat[1] <- 0
  for (t in 2:habitats){
    alpha.UAV.habitat[t] ~ dnorm(0,1)
    alpha.ground.habitat[t] ~ dnorm(0,1)
  }
  
  
  
  
  # define each observation psi and assign to matrix omega
  for (i in 1:obs){
    
    # define probabilities for this observation
    logit(psi.ground[i]) <- alpha.ground + alpha.trial[trial[i]] +  alpha.transect[transect[i]] + alpha.ground.habitat[habitat[i]]
    logit(psi.UAV[i]) <- alpha.UAV + alpha.trial[trial[i]] + alpha.transect[transect[i]] + alpha.UAV.habitat[habitat[i]]
    
    # define both probability as related to above
    psi.both[i] <- 1-(psi.ground[i] + psi.UAV[i])
    
    # create matrix
    Omega[i,1] <- psi.ground[i]
    Omega[i,2] <- psi.UAV[i]
    Omega[i,3] <- psi.both[i]
    
  }
  
  
  
  ###################################
  # likelihood
  
  for (i in 1:obs){
    
    y[i] ~ dcat(Omega[i,1:3])
    
    
  }
  
  
  ###############################################
  # Derived quantity: Total abundance across all surveyed sites
  mean.both <- mean(psi.both[1:obs])
  
})


## model data set up####

jags.data <- list(y=ungulates$category)

jags.constants <- list(obs=nrow(ungulates),
                       trials=2,
                       trial=ungulates$Trial,
                       transects=6,
                       transect=ungulates$Transect,
                       habitats=3,
                       habitat=ungulates$Habitat)

parameters <- c("mean.both", "mean.ground", "mean.UAV",
                "psi.both", "psi.ground", "psi.UAV",
                "alpha.trial", "mu.trial", "sig.trial",
                "alpha.transect", "mu.transect", "sig.transect",
                "alpha.ground.habitat", "alpha.UAV.habitat")
#


inits <- list(mean.ground = 0.4,               
              mean.UAV = 0.4,
              mu.trial = 0,
              sig.trial = runif(1,0,1),
              mu.transect = 0,
              sig.transect = runif(1,0,1),
              alpha.trial = rep(0,2),
              alpha.transect = rep(0,6),
              alpha.UAV.habitat = rep(0,3),
              alpha.ground.habitat = rep(0,3))



# running model ####

model.detection.habitat.int <- nimbleModel(
  detection.habitat.int,
  constants = jags.constants, 
  data = jags.data,
  inits = inits)


# compile model
cmodel.object.detection.habitat.int <- compileNimble(model.detection.habitat.int, dirName = "C:/R-Packages")
# create a MCMC configuration
Config.detection.habitat.int <- configureMCMC(cmodel.object.detection.habitat.int)
# add things to monitor!
Config.detection.habitat.int$addMonitors(parameters)

model.object.detection.habitat.int.built <- buildMCMC(Config.detection.habitat.int)
cMCMC.detection.habitat.int <- compileNimble(model.object.detection.habitat.int.built, project = cmodel.object.detection.habitat.int,
                                             resetFunctions = TRUE)

s <- Sys.time()
samples.detection.habitat.int <- runMCMC(cMCMC.detection.habitat.int, niter = 200000, nburnin = 50000, nchains = 3, thin = 2)
print(t <- Sys.time() - s)



# check all Rhat <1.1
as.data.frame(MCMCsummary(samples.detection.habitat.int)) %>% arrange(-Rhat) %>% head()

# check an example trace plot
MCMCtrace(samples.detection.habitat.int, params = c("mean.ground"), pdf=F, type = "trace", ISB=F)






# extract bits of interest for graph/table
model.outputs <- as.data.frame(MCMCsummary(samples.detection.habitat.int, params = c("mean.both", "mean.ground", "mean.UAV",
                                                                                     "alpha.trial", "alpha.transect", "alpha.UAV.habitat",
                                                                                     "alpha.ground.habitat"))) %>% 
  mutate(param = rownames(.)) %>% 
  mutate(param = stringr::str_remove_all(param, "\\["),
         param = stringr::str_remove_all(param, "\\]")) %>% 
  # name each level
  mutate(name=case_when(param=="mean.both" ~ "Both",
                        param=="mean.ground" ~ "Ground only",
                        param=="mean.UAV" ~ "UAV only",
                        grepl("alpha.trial", param) ~ stringr::str_replace(param, "alpha.trial", "Trial "),
                        param=="alpha.transect1" ~ "W035",
                        param=="alpha.transect2" ~ "W036",
                        param=="alpha.transect3" ~ "W037",
                        param=="alpha.transect4" ~ "W038",
                        param=="alpha.transect5" ~ "W069",
                        param=="alpha.transect6" ~ "W073",
                        param=="alpha.UAV.habitat1" ~ "Deciduous\nForest",
                        param=="alpha.UAV.habitat2" ~ "Evergreen\nForest",
                        param=="alpha.UAV.habitat3" ~ "Open\nLand",
                        param=="alpha.ground.habitat1" ~ "Deciduous\nForest",
                        param=="alpha.ground.habitat2" ~ "Evergreen\nForest",
                        param=="alpha.ground.habitat3" ~ "Open\nLand")) %>% 
  select(name, param, mean, sd, LCI=`2.5%`, UCI=`97.5%`, Rhat)


# means for each survey type
ggplot(filter(model.outputs, param%in%c("mean.both","mean.ground","mean.UAV")),
       aes(x=name, y=mean)) +
  geom_point(size=3) +
  geom_errorbar(aes(x=name, ymin=LCI, ymax=UCI), linewidth=1.5) +
  theme_classic() +
  ylab("Probability")  +
  scale_y_continuous(limits=c(0,1)) +
  xlab("Parameter") +
  theme(axis.title = element_text(size=40), axis.text=element_text(size=35))
# all CI overlapping


# means for trials
ggplot(filter(model.outputs, grepl("trial", param)),
       aes(x=name, y=mean)) +
  geom_point(size=3) +
  geom_errorbar(aes(x=name, ymin=LCI, ymax=UCI), linewidth=1.5) +
  theme_classic() +
  ylab("Probability") +
  xlab("Parameter") +
  theme(axis.title = element_text(size=40), axis.text=element_text(size=35))
# all CI overlapping


# means for transects
ggplot(filter(model.outputs, grepl("transect", param)),
       aes(x=name, y=mean)) +
  geom_point(size=3) +
  geom_errorbar(aes(x=name, ymin=LCI, ymax=UCI), linewidth=1.5) +
  theme_classic() +
  ylab("Probability") +
  xlab("Parameter") +
  theme(axis.title = element_text(size=40), axis.text=element_text(size=35))
# all CI overlapping


# add column for UAV or Ground only
model.outputs <- model.outputs %>% mutate(type=case_when(grepl("UAV", param) ~ "UAV only",
                                                         grepl("ground",param) ~ "Ground only"))
# Figure 6 ####

# habitat effects
ggplot(filter(model.outputs, grepl("habitat", param)),
       aes(x=name, y=mean, colour=name)) +
  geom_point(size=3) +
  geom_errorbar(aes(x=name, ymin=LCI, ymax=UCI, colour=name), linewidth=1.5) +
  facet_grid(.~type) +
  theme_classic() +
  ylab("Probability") +
  xlab("Habitat") +
  theme(axis.title = element_text(size=40), axis.text=element_text(size=35),
        strip.text = element_text(size=40), legend.position = "none") +
  scale_colour_manual(values=c("forestgreen", "navy", "brown"))
# no differences

ggsave("results/habitat_means_interaction.jpeg", width=20, height=10)



# Table 4 ####

model.sum <- model.outputs %>% 
  mutate(effect=case_when(grepl("trial", param) ~ "Trial (random effect)",
                          grepl("transect", param) ~ "Transect (random effect)",
                          grepl("UAV.habitat", param) ~ "Habitat (UAV)",
                          grepl("ground.habitat", param) ~ "Habitat (ground)",
                          T ~ "Detection mean")) %>% 
  select(effect, name, mean, LCI, UCI) %>% 
  mutate(name=stringr::str_replace(name, "\n", " ")) %>% 
  arrange(effect) %>% 
  mutate(across(mean:UCI, ~round(.x,2)))

write.csv(model.sum, "results/model_sum_interaction.csv", row.names = F)


########### occlusion ####


# Tables 5 and 6: habitat and ungulate summaries  ####


# unbgulate data 
deer.hab.occ.T1 <- read.csv("data/T1_ungulate_habitat_occlusion.csv") %>% 
  mutate(Transect=case_when(Transect=="Wo61"~ "W061", T ~ Transect)) %>% 
  mutate(Trial="Trial 1")
# duplicates
deer.hab.occ.T1 <- unique(deer.hab.occ.T1) 

deer.hab.occ.T2 <- read.csv("data/T2_ungulate_habitat_occlusion.csv") %>% 
  mutate(Trial="Trial 2")
# duplicates
deer.hab.occ.T2 <- unique(deer.hab.occ.T2) 

# combine, give sensible names and make habitat names readable 
deer.hab.occ <- rbind(deer.hab.occ.T1, deer.hab.occ.T2) %>% 
  select(Trial, Transect, Species, Habitat=Nw_Hab_Cat, occlusion=occlusionm) %>% 
  mutate(Habitat=stringr::str_replace_all(Habitat, "_", " "))


# habitat data
all.habitat <- read.csv("data/All_transects_habitat.csv")

all.habitat <- all.habitat %>% 
  select(Transect, Habitat=Nw_Hab_Cat, Area=Area.calc)%>% 
  mutate(Habitat=stringr::str_replace_all(Habitat, "_", " "))



# Table 5 - per transect
# number of ungulates per habitat per transect
deer.hab.sum <- deer.hab.occ %>% group_by(Trial, Transect, Habitat) %>% 
  summarise(n=n()) %>% 
  # merge to make sure have all habitat and zeros
  merge(unique(select(deer.hab.occ, Trial, Transect)) %>% 
          cbind(Habitat=rep(unique(deer.hab.occ$Habitat), each=11)), all=T) %>% 
  mutate(n=replace_na(n,0)) %>% 
  # pivot so trial 1 and 2 are columns
  pivot_wider(names_from = Trial, values_from = n) %>% 
  arrange(Transect, Habitat)

# percentage habitat per transect
transect.habitat <- all.habitat %>% group_by(Transect, Habitat) %>% 
  summarise(area=sum(Area)) %>% 
  merge(all.habitat %>% group_by(Transect) %>% 
          summarise(tot.area=sum(Area))) %>% 
  mutate(perc = area/tot.area*100,
         perc=round(perc,0)) %>% 
  select(Transect, Habitat, percentage=perc)

# combine
deer.hab.sum <- deer.hab.sum %>% merge(transect.habitat, by=c("Transect", "Habitat"), all=T) %>% 
  mutate(percentage=replace_na(percentage,0)) %>% 
  select(Transect, Habitat, percentage, everything())

# table 5
write.csv(deer.hab.sum, "results/Transect_habitat_ungulates.csv")




# Table 6
# deer by habitat overall
deer.hab.sum2 <- deer.hab.occ %>% group_by(Trial, Habitat) %>% 
  summarise(n=n()) %>% 
  pivot_wider(names_from = Trial, values_from = n) %>% 
  merge(data.frame(Habitat=unique(deer.hab.occ$Habitat)), all=T) %>% 
  mutate(`Trial 2`=replace_na(`Trial 2`,0))

# total habitat percentages
hab.sum <- all.habitat %>% group_by(Habitat) %>% 
  summarise(area=sum(Area)) %>% 
  mutate(percentage=round(area/sum(area)*100)) %>% 
  select(Habitat, percentage)

deer.hab.sum2 <- hab.sum %>% merge(deer.hab.sum2, all=T)

# table 6
write.csv(deer.hab.sum2, "results/deer_per_habitat.csv")





# Figure 7: occlusion by species across Trials ####

occlusion.T1 <- read.csv("data/T1_ungulate_occlusion.csv")
occlusion.T2 <- read.csv("data/T2_ungulate_occlusion.csv")

# combined
occ.species <- rbind(occlusion.T1, occlusion.T2)
# better graphing labels
occ.species <- occ.species %>% mutate(Species=case_when(Species=="Unknown deer" ~ "Unknown\ndeer",
                                                        T ~ Species))
# order for graph
occ.species$Species <- factor(occ.species$Species, levels=c("Unknown\ndeer","Muntjac","Roe","Fallow","Boar"))


ggplot(occ.species, aes(x=occlusionm*100, y=Species)) +
  geom_boxplot() +
  geom_point(size=2.5, position = position_jitter(width = 0, height=0.1)) +
  theme_classic() +
  xlab("Occlusion (%)") +
  theme(axis.title = element_text(size=40), axis.text=element_text(size=35))

ggsave("results/occlusion_species.jpeg", width=20, height=10, dpi="retina")

# number geolocated
nrow(occ.species) # 85

# for each species
occ.species%>% group_by(Species) %>% 
  summarise(n=n())


# Figure 8: occlusion by habitat across Trials ####

occ.habitat.T1 <- read.csv("data/T1_habitat_occlusion.csv")

occ.habitat.T1 <- occ.habitat.T1 %>% select(Habitat=Nw_Hab_Cat, occlusion.mean=occlusionm, occlusion.std=occlusions) %>% mutate(Trial="Trial 1")


occ.habitat.T2 <- read.csv("data/T2_habitat_occlusion.csv")

occ.habitat.T2 <- occ.habitat.T2 %>% select(Habitat=Nw_Hab_Cat, occlusion.mean=occlusionm, occlusion.std=occlusions) %>% mutate(Trial="Trial 2")


# combine
occ.habitat <- rbind(occ.habitat.T1, occ.habitat.T2)


# better labels for graph
occ.habitat <- occ.habitat %>% mutate(Habitat=stringr::str_replace_all(Habitat, "_", " "))

occ.habitat <- occ.habitat %>% mutate(Habitat=case_when(Habitat=="Deciduous Forest" ~ "Deciduous\nForest",
                                                        Habitat=="Young Forest" ~"Young\nForest",
                                                        Habitat=="Evergreen Forest" ~"Evergreen\nForest",
                                                        T ~ Habitat))

# order for graph
occ.habitat$Habitat <- factor(occ.habitat$Habitat, levels=c("Open Land","Young\nForest", "Deciduous\nForest", "Evergreen\nForest" ))




ggplot(occ.habitat, aes(x=occlusion.mean, y=Habitat, colour=Habitat)) +
  geom_point(size=5) +
  geom_errorbar(aes(y=Habitat, xmin=occlusion.mean-occlusion.std, xmax=occlusion.mean+occlusion.std), 
                linewidth=2) +
  theme_classic() +
  scale_x_continuous(limits=c(-0.25,1.2), breaks=seq(-0.2,1.2,0.2))+
  xlab("Percentage occlusion") +
  theme(axis.title = element_text(size=40), axis.text=element_text(size=35),
        strip.text = element_text(size=40),
        legend.position = "none") +
  facet_grid(Trial~.) +
  scale_colour_manual(values=c("#B2182B", "#F4A582","#92C5DE","#2166AC"))


ggsave("results/occlusion_habitat.jpeg", width=20, height=15, dpi="retina")


occ.habitat2 <- occ.habitat %>% 
  mutate(lower=occlusion.mean-occlusion.std,
         upper=occlusion.mean+occlusion.std) %>% 
  mutate(lower=case_when(lower<0~0, T~lower),
         upper=case_when(upper>1~1, T ~ upper))

ggplot(occ.habitat2, aes(x=occlusion.mean*100, y=Habitat, colour=Habitat)) +
  geom_point(size=5) +
  geom_errorbar(aes(y=Habitat, xmin=lower*100, xmax=upper*100), 
                linewidth=2) +
  theme_classic() +
  #scale_x_continuous(limits=c(-0,1), breaks=seq(-0.2,1.2,0.2))+
  xlab("Occlusion (%)") +
  theme(axis.title = element_text(size=40), axis.text=element_text(size=35),
        strip.text = element_text(size=40),
        legend.position = "none") +
  facet_grid(Trial~.) +
  scale_colour_manual(values=c("#B2182B", "#F4A582","#92C5DE","#2166AC"))

ggsave("results/occlusion_habitat2.jpeg", width=20, height=15, dpi="retina")

# Table 7: occlusion by transect by Trial  ####

occ.transect.T1 <- read.csv("data/T1_transect_occlusion.csv")

occ.transect.T1 <- occ.transect.T1 %>% select(Transect, occlusion.mean.T1=occlusionm, occlusion.std.T1=occlusions) %>% 
  filter(Transect!="W037") %>% 
  mutate(occlusion.mean.T1=round(occlusion.mean.T1,3),
         occlusion.std.T1=round(occlusion.std.T1,3)) %>% 
  arrange(Transect)

#ADD
occ.transect.T2 <- read.csv("data/T2_transect_occlusion.csv")

occ.transect.T2 <- occ.transect.T2 %>% select(Transect, occlusion.mean.T2=occlusionm, occlusion.std.T2=occlusions) %>% 
  mutate(occlusion.mean.T2=round(occlusion.mean.T2,3),
         occlusion.std.T2=round(occlusion.std.T2,3)) %>% 
  arrange(Transect)


occ.transect <- merge(occ.transect.T1, occ.transect.T2, all=T)



write.csv(occ.transect, "results/occlusion_transect.csv", row.names = F)

















